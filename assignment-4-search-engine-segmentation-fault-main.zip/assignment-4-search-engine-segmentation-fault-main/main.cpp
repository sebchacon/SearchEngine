#include "SearchEngine.h"


int main(int argc, char** argv)
{

   SearchEngine engine;
   engine.ui(argc, argv);

    return 0;
}